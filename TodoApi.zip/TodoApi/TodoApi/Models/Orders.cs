namespace TodoApi.Models
{
    public class Orders
    {
        public int id { get; set; }
        public int Customer_id { get; set; }
        public System.DateTime Date { get; set; }
    }
}