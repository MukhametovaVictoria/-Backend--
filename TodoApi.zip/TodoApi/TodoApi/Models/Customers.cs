namespace TodoApi.Models
{
    public class Customers
    {
        
        public int id { get; set; }
        public string name { get; set; }
    }
}