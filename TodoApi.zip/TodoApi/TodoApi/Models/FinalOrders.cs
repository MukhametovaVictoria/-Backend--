namespace TodoApi.Models
{
    public class FinalOrders
    {
        public int id { get; set; }
        public string Product_list { get; set; }
        public string Customer_name { get; set; }
        public System.DateTime Date { get; set; }
    }
}