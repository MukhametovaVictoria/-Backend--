namespace TodoApi.Models
{
    public class Products
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}